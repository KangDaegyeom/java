import java.util.Scanner;

public class Dictionary {
    private static String[] kor = { "사랑", "아기", "돈", "미래", "희망" };
    private static String[] eng = { "love", "baby", "money", "future", "hope" };
    public static String kor2Eng(String word){
        for(int i = 0; i < 5; i++){
            if(word.equals(kor[i])){
                return eng[i];
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("한영 단어 검색 프로그램입니다.");
        while(true){
            System.out.print("한글 단어?");
            String a = scanner.next();
            if(a.equals("그만")) break;
            String result = kor2Eng(a);
            if(result!=null) System.out.println(a + "는 " + result);
            else System.out.println(a + "는 저의 사전에 없습니다.");
        }
    }
}
