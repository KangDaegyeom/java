import java.util.Scanner;

public class Concert {
    String[] seats;
    public Concert(){
        seats = new String[10];
        for(int i = 0; i < 10; i++){
            seats[i]= "---";
        }
    }
    public static void Book(Concert arr, String name, int num){
        arr.seats[num-1] = name;
    }

    public static void show(Concert[] arr){
        char[] grade;
        grade = new char[]{'S', 'A', 'B'};
        for(int i = 0; i < 3; i++){
            System.out.print(grade[i]+">> ");
            for(int j = 0; j < 10; j++){
                System.out.print(arr[i].seats[j]+" ");
            }
            System.out.println();
        }
        System.out.println("<<조회를 완료하였습니다.>>");
    }

    public static void cancel(Concert arr, String name){
        System.out.print("이름>>");
        for(int i = 0; i < 10; i++){
            if(name.equals(arr.seats[i])){
                arr.seats[i] = "---";
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Concert[] arr;
        arr = new Concert[3];
        char[] grade;
        grade = new char[]{'S', 'A', 'B'};
        for(int i = 0; i < 3; i++){
            arr[i]=new Concert();
        }
        System.out.println("명품콘서트홀 예약 시스템입니다.");
        while(true){
            System.out.print("예약:1, 조회:2, 취소:3, 끝내기:4>>");
            int select = scanner.nextInt();
            if(select == 1) {
                System.out.print("좌석구분 S(1), A(2), B(3)>>");
                int seat = scanner.nextInt();
                System.out.print(grade[seat-1]+">> ");
                for(int i = 0; i < 10; i++){
                    System.out.print(arr[seat-1].seats[i]+" ");
                }
                System.out.println();
                System.out.print("이름>>");
                String name = scanner.next();
                System.out.print("번호>>");
                int num = scanner.nextInt();
                Book(arr[seat-1], name, num);
            }
            else if(select == 2) show(arr);
            else if(select == 3) {
                System.out.print("좌석 S(1), A(2), B(3)>>");
                int a = scanner.nextInt();
                for(int i = 0; i < 10; i++){
                    System.out.print(arr[a-1].seats[i]+" ");
                }
                System.out.println();
                System.out.print("이름>>");
                String name = scanner.next();
                cancel(arr[a-1], name);
            }
            else if(select == 4) break;
        }
    }
}
